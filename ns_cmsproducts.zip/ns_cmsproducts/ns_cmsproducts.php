<?php

if (!defined('_PS_VERSION_'))
exit;



/*use PrestaShop\PrestaShop\Core\Module\WidgetInterface; */
use PrestaShop\PrestaShop\Adapter\Category\CategoryProductSearchProvider;
use PrestaShop\PrestaShop\Adapter\Image\ImageRetriever;
use PrestaShop\PrestaShop\Adapter\Product\PriceFormatter;
use PrestaShop\PrestaShop\Core\Product\ProductListingPresenter;
use PrestaShop\PrestaShop\Adapter\Product\ProductColorsRetriever;
use PrestaShop\PrestaShop\Core\Product\Search\ProductSearchContext;
use PrestaShop\PrestaShop\Core\Product\Search\ProductSearchQuery;
use PrestaShop\PrestaShop\Core\Product\Search\SortOrder;



require_once(dirname(__FILE__) . '/classes/NsCategoryCms.php');



class ns_cmsproducts extends Module
{



	public function __construct()
	{

	$this->name = 'ns_cmsproducts';
	$this->tab = 'administration';
	$this->version = '1.0.0';
	$this->author = 'NdiagaSoft';
	$this->need_instance = 0;
	$this->secure_key = Tools::encrypt($this->name);
	$this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
	$this->bootstrap = true;


	parent::__construct();

	$this->displayName = $this->l('NS CMS Products');
	$this->description = $this->l('CMS  Related Products.');

	$this->confirmUninstall = $this->l('Are you sure you want to uninstall?');


	}


	public function install()
	{

	$sql = array();	

	$sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'ns_cms_category` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`id_cms` int(11),
	`id_category` int(11),	
	`page_description` text,	
	PRIMARY KEY (`id`)
	) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8';


	if (!parent::install() ||
	!$this->registerHook('displayCMSProduct')||
	!$this->registerHook('displayCMSPrintButton')||
	!$this->registerHook('displayCMSDisputeInformation')||	
	!$this->runSql($sql)

	)
	return false;
     
	 
	 
	return true;
	}

	public function uninstall()
	{

	$sql = array();

	$sql[] = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'ns_cms_category`';	

	if (!parent::uninstall() ||
	!$this->runSql($sql)
	)
	return false;
	
	

	return true;
	}

	public function runSql($sql) {
	foreach ($sql as $s) {
	if (!Db::getInstance()->Execute($s)){
	return FALSE;
	}
	}

	return TRUE;
	}

	


	public function getContent()
	{
	
	
	    $output ='<div  class="panel">';
		$output .='You are ready to go ! Just  go to the file:<br/>';
		$output .= 'themes/classic/templates/cms/page.tpl <br/>';
		$output .='Inside  the tag "section"  and place this line of code:<br/>';
		$output .=" {hook h='displayCMSProduct'}   <br/>";		
		$output .= 'And you  are ready to go !<br/>';		
		$output .='</div>';
		
		
	$output.=$this->addMenu();
	
	$output.=$this->AssociateNew();
	
	if(Tools::isSubmit('viewData') || Tools::isSubmit('deletens_cms_category')){	

       if(Tools::getValue('id')!=''){
		   
		   $id=(int)Tools::getValue('id');		   
		   $NsCategoryCms=new NsCategoryCms($id);
		   
		   $NsCategoryCms->delete();
		   
		   $output.= $this->displayConfirmation($this->l('Item removed successfully !'));
		   
	   }	
		
		$output.=$this->renderCategoryList();
	}
	
	elseif(Tools::isSubmit('viewCMSCats') || Tools::isSubmit('submitCMSCat')){	
     
       if(Tools::isSubmit('submitCMSCat')){	 
	 
        $id_cms_category =Tools::getValue('id_cms_category');
		
        if (empty($id_cms_category))
            $output .= $this->displayError($this->l('Invalid Configuration value'));
        else
        {
            Configuration::updateValue('CMS_DEFAULT_CAT', $id_cms_category);		
		
            $output.= $this->displayConfirmation($this->l('Settings updated'));
        }
		
		
	  }
		
		$output.=$this->displayCMSForm();
	}
	
	
	else{
		
		$output.=$this->displayCategoryForm();
		
	}

	
	
	

	return $output;

	}
	
	
	
	public function addMenu(){

	$button= '<div class="panel">';
	$button .= '<a href="'.$this->context->link->getAdminLink('AdminModules', false).'&viewHome&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules').'">
	<button class="btn btn-default">'.$this->l('Home').'</button>
	</a>';
	$button .= '<a href="'.$this->context->link->getAdminLink('AdminModules', false).'&viewData&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules').'">
	<button class="btn btn-default">'.$this->l('Category CMS').'</button>
	</a>';	
	
	$button .= '<a href="'.$this->context->link->getAdminLink('AdminModules', false).'&viewCMSCats&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules').'">
	<button class="btn btn-default">'.$this->l('Select CMS Root Category').'</button>
	</a>';	
	
	
	$button .='</div>';



	return $button;

	}   
   
	/*category list*/

	public function renderCategoryList()
	{
	$fields_list = array(

	'id' => array(
	'title' => $this->l('ID'),
	'search' => false,
	),	
	'meta_title' => array(
	'title' => $this->l('CMS Page'),
	'search' => false,
	),	
	'name' => array(
	'title' => $this->l('Product Category'),
	'search' => false,
	),
	'page_description' => array(
	'title' => $this->l('Page call to action'),
	'search' => false,
	)
	);

	if (!Configuration::get('PS_MULTISHOP_FEATURE_ACTIVE'))
	unset($fields_list['shop_name']);
	$helper_list = New HelperList();
	$helper_list->module = $this;
	$helper_list->title = $this->l('CMS Associated Categories');
	$helper_list->shopLinkType = '';
	$helper_list->no_link = true;
	$helper_list->show_toolbar = true;
	$helper_list->simple_header = false;
	$helper_list->identifier = 'id';
	$helper_list->table = 'ns_cms_category';
	$helper_list->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name;
	$helper_list->token = Tools::getAdminTokenLite('AdminModules');
	$helper_list->actions = array('delete');
	$helper_list->bulk_actions = array(
	'select' => array(
	'text' => $this->l('Change order status'),
	'icon' => 'icon-refresh',
	)
	);

	/*This is needed for displayEnableLink to avoid code duplication*/
	$this->_helperlist = $helper_list;

	/* Retrieve list data */
	$id_lang=$this->context->language->id;
	
	$orders=NsCategoryCms::getAllCMSCategories($id_lang);
	$helper_list->listTotal = count(NsCategoryCms::getAllCMSCategories($id_lang));

	/* Paginate the result */
	$page = ($page = Tools::getValue('submitFilter'.$helper_list->table)) ? $page : 1;
	$pagination = ($pagination = Tools::getValue($helper_list->table.'_pagination')) ? $pagination : 50;
	$orders = $this->paginateOrderProducts($orders, $page, $pagination);

	return $helper_list->generateList($orders, $fields_list);

	}


	public function paginateOrderProducts($orders, $page = 1, $pagination = 50)
	{
	if(count($orders) > $pagination)
	$orders= array_slice($orders, $pagination * ($page - 1), $pagination);

	return $orders;
	}


	public function AssociateNew(){

	$message='';
	
	if(Tools::isSubmit('submitAssociateCategoryForm') && Tools::getValue('id_cms')!='' && Tools::getValue('categoryBox')!='')
	{
    
	$id_cms=Tools::getValue('id_cms');
	$sampleObj = NsCategoryCms::loadByIdImage($id_cms);
	$sampleObj->page_description= Tools::getValue('page_description');	
	$sampleObj->id_cms = Tools::getValue('id_cms');
	$sampleObj->id_category= Tools::getValue('categoryBox');	
	
	if(!empty($sampleObj) && isset($sampleObj->id))
	{
		$sampleObj->update();    
	
	 $message= $this->displayConfirmation($this->l('New  Value added Successfully'));

	}	

   else{
	   $sampleObj->add();    
	
	 $message= $this->displayConfirmation($this->l('New  Value added Successfully'));
	   
	   
   }	

	}
	
	return  $message;

	}		

	/* category form */

	public function displayCategoryForm()
	{
		
     
	$root =Category::getRootCategory();
	$selected_cat =array($root->id);
	$tree = new HelperTreeCategories('categories-treeview', $this->l('Choose a category') );
	//$tree->setUseCheckBox(true);
	$tree->setAttribute('is_category_filter', $root->id)
	->setRootCategory($root->id)
	->setSelectedCategories($selected_cat)
	->setUseSearch(true);

	$id_lang=(int)$this->context->language->id;
	$categories=Category::getCategories($id_lang, true,true);
	
	$id_cms_category=(int)Configuration::get('CMS_DEFAULT_CAT');

	$this->context->smarty->assign(
	array(
	'categories_tree'=>$tree->render(),
	'all_categories'=>$categories,	
	'cms_pages'=>NsCategoryCms::getCMSPages($id_cms_category,false),
	'token'=>Tools::getAdminTokenLite('AdminModules'),	

	)
	);

	return $this->display(__FILE__, 'views/templates/admin/admin_employees.tpl');

	}


	
   public function displayCMSForm()
  {
    // Get default language
    $default_lang = (int)Configuration::get('PS_LANG_DEFAULT');
	$id_shop=Context::getContext()->shop->id;;
	$id_lang=(int)Context::getContext()->language->id; 
    
	
	//$cms_categories=CMSCategory::getCategories($id_lang,true,true);
	$cms_categories=CMSCategory::getSimpleCategories($id_lang);
    // Init Fields form array
    $fields_form[0]['form'] = array(
        'legend' => array(
            'title' => $this->l('Settings'),
			'icon' => 'icon-cogs'
        ),
        'input' => array(
			array(
					'type' => 'select',
					'label' => $this->l('Select a CMS Category'),
					'name' => 'id_cms_category',
					
					'options' => array(
						'query' =>$cms_categories,
						'id' => 'id_cms_category',
						'name' => 'name'
						
					),
					'desc' => $this->l('Select the default CMS category for the Blog.')
                      ),
					  
			 

      					  
        ),
        'submit' => array(
            'title' => $this->l('Save'),           
        )
    );
     
    $helper = new HelperForm();
     
    // Module, token and currentIndex
    $helper->module = $this;
    $helper->name_controller = $this->name;
    $helper->token = Tools::getAdminTokenLite('AdminModules');
    $helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;
     
    // Language
    $helper->default_form_language = $default_lang;
    $helper->allow_employee_form_lang = $default_lang;
     
    // Title and toolbar
    $helper->title = $this->displayName;
    $helper->show_toolbar = true;        // false -> remove toolbar
    $helper->toolbar_scroll = true;      // yes - > Toolbar is always visible on the top of the screen.
    $helper->submit_action = 'submitCMSCat';
    $helper->toolbar_btn = array(
        'save' =>
        array(
            'desc' => $this->l('Save'),
            'href' => AdminController::$currentIndex.'&configure='.$this->name.'&save'.$this->name.
            '&token='.Tools::getAdminTokenLite('AdminModules'),
        ),
        'back' => array(
            'href' => AdminController::$currentIndex.'&token='.Tools::getAdminTokenLite('AdminModules'),
            'desc' => $this->l('Back to list')
        )
    );
     
    /*Load current value*/    
	

	$helper->fields_value['id_cms_category'] =Configuration::get('id_cms_category')? Configuration::get('id_cms_category'):Tools::getValue('id_cms_category');
	
	
	
     
    return $helper->generateForm($fields_form);
	
	
    }   
	
	
	public function  hookDisplayCMSProduct($params){
		
		$id_cms=(int)Tools::getValue('id_cms');
		
		$NsCategoryCms=NsCategoryCms::loadByIdImage($id_cms);
		
	if(!empty($NsCategoryCms)  && isset($NsCategoryCms->id))
	{	
		$id_category=(int)$NsCategoryCms->id_category;		
		
		$products=$this->getProducts($id_category);	
		
		
		  $this->context->smarty->assign(
	     array(	
	      'CmsData'=>$NsCategoryCms,
          'category_products'=>$products, 		  

	      )
	      );
	
    return $this->display(__FILE__, 'display_cms_product.tpl');
		  
	}  
		  
    }
	
	
	   protected function getProducts($id_category)
    {
        $category=new Category($id_category);

        $searchProvider = new CategoryProductSearchProvider(
            $this->context->getTranslator(),
            $category
        );

        $context = new ProductSearchContext($this->context);

        $query = new ProductSearchQuery();

        $nProducts =4; //Configuration::get('HOME_FEATURED_NBR');
        if ($nProducts < 0) {
            $nProducts =4;
        }

        $query
            ->setResultsPerPage($nProducts)
            ->setPage(1)
        ;

        if (Configuration::get('HOME_FEATURED_RANDOMIZE')) {
            $query->setSortOrder(SortOrder::random());
        } else {
            $query->setSortOrder(new SortOrder('product', 'position', 'asc'));
        }

        $result = $searchProvider->runQuery(
            $context,
            $query
        );

        $assembler = new ProductAssembler($this->context);

        $presenterFactory = new ProductPresenterFactory($this->context);
        $presentationSettings = $presenterFactory->getPresentationSettings();
        $presenter = new ProductListingPresenter(
            new ImageRetriever(
                $this->context->link
            ),
            $this->context->link,
            new PriceFormatter(),
            new ProductColorsRetriever(),
            $this->context->getTranslator()
        );

        $products_for_template = [];

        foreach ($result->getProducts() as $rawProduct) {
            $products_for_template[] = $presenter->present(
                $presentationSettings,
                $assembler->assembleProduct($rawProduct),
                $this->context->language
            );
        }

        return $products_for_template;
    }
	
	


}
