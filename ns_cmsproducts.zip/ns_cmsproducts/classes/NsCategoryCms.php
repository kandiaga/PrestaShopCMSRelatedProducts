<?php


class NsCategoryCms extends ObjectModel
{
	/** @var string Name */
	public $id;		
	/** @var integer */
	public $id_category;	
	public $id_cms;	
	/** @var integer */
	public $page_description;
	
	
	
    /**
     * @see ObjectModel::$definition
     */
    public static $definition = array(
        'table' => 'ns_cms_category',
        'primary' => 'id',
        'multilang' => FALSE,
        'fields' => array(
            'id_cms' => array('type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => TRUE),
			'id_category' =>array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId'),			
            'page_description' => array('type' => self::TYPE_HTML, 'validate' => 'isCleanHtml'),
			
        ),
    );
	
    public static function loadByIdImage($id_cms){
        $result = Db::getInstance()->getRow('
            SELECT *
            FROM `'._DB_PREFIX_.'ns_cms_category` sample
            WHERE sample.`id_cms` = '.(int)$id_cms
        );
        
        return new NsCategoryCms($result['id']);
    }
	
	
	public  static  function getAllCMSCategories($id_lang){
		
		$result = Db::getInstance()->executeS('
            SELECT *
            FROM `'._DB_PREFIX_.'ns_cms_category` sample
			LEFT JOIN `'._DB_PREFIX_.'category_lang` cl ON  cl.id_category=sample.id_category  AND  cl.id_lang='.(int)$id_lang.'
			LEFT JOIN `'._DB_PREFIX_.'cms_lang` cml ON (cml.`id_cms` = sample.`id_cms`)  AND  cml.id_lang='.(int)$id_lang  
            
        );
		
		
		return $result;
		
	}
	
	
	public static function getCMSPages($id_cms_category, $id_shop = false)
	{
        $id_shop = ($id_shop !== false) ? $id_shop : Context::getContext()->shop->id;

		$sql = 'SELECT c.`id_cms`, cl.`meta_title`, cl.`link_rewrite` , cl.`content`
			FROM `'._DB_PREFIX_.'cms` c
			INNER JOIN `'._DB_PREFIX_.'cms_shop` cs
			ON (c.`id_cms` = cs.`id_cms`)
			INNER JOIN `'._DB_PREFIX_.'cms_lang` cl
			ON (c.`id_cms` = cl.`id_cms`)
			WHERE c.`id_cms_category` = '.(int)$id_cms_category.'
			AND cs.`id_shop` = '.(int)$id_shop.'
			AND cl.`id_lang` = '.(int)Context::getContext()->language->id.'
			AND c.`active` = 1
			ORDER BY `position`';

		return Db::getInstance()->executeS($sql);
	}
	
	
	
}

